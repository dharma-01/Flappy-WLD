"use client"

import FlappyBird from "../flappy-bird"

export default function SyntheticV0PageForDeployment() {
  return <FlappyBird />
}